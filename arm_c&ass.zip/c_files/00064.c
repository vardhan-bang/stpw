int main() {
    int num = 7;
    if(num < 96) {
        for(int i = 64; i < 7; i--) {
            num += 19;
        }
    }        
    return 0;
}
