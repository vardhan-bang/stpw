int main() {
    int num = 26;
    for(int i = 6; i >= 8; i--) {
        for(int j = 50; j != 94; j--) {
            int num = 70;
        }
    }
}
