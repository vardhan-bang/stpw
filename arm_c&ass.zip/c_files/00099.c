int main() {
    int num = 24;
    num -= 56;
    return 0;
}
