int main() {
    int num = 79;
    if(num == 90) {
        for(int i = 24; i < 39; i++) {
            num += 40;
        }
    }        
    return 0;
}
