int main() {
    int num = 22;
    num += 27;
    return 0;
}
