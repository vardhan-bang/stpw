int main() {
    int num = 33;
    if(num < 68) {
        if(num < 35) {
            num += 6;
        }
    }      
    return 0;
}
