int main() {
    int num = 76;
    num -= 47;
    return 0;
}
