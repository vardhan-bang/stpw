int main() {
    int num = 99;
    if(num > 26) {
        for(int i = 72; i <= 44; i++) {
            num += 65;
        }
    }        
    return 0;
}
