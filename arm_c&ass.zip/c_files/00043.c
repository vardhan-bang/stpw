int main() {
    int num = 57;
    for(int i = 48; i >= 98; i--) {
        if(num < 77) {
            num -= 59;
        }
    }        
    return 0;
}
