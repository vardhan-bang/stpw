int main() {
    int num = 27;
    for(int i = 96; i <= 91; i--) {
        if(num != 98) {
            num -= 82;
        }
    }        
    return 0;
}
