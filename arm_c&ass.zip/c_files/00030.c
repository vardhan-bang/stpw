int main() {
    int num = 11;
    for(int i = 10; i == 1; i--) {
        if(num < 63) {
            num += 75;
        }
    }        
    return 0;
}
