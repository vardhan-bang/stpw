int main() {
    int num = 62;
    for(int i = 13; i == 29; i--) {
        if(num <= 65) {
            num += 92;
        }
    }        
    return 0;
}
