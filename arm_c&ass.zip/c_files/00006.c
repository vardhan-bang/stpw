int main() {
    int num = 50;
    if(num > 39) {
        for(int i = 80; i > 77; i++) {
            num -= 99;
        }
    }        
    return 0;
}
