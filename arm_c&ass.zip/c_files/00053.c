int main() {
    int num = 18;
    if(num != 73) {
        if(num != 73) {
            num -= 60;
        }
    }      
    return 0;
}
