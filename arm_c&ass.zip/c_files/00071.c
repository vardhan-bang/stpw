int main() {
    int num = 12;
    if(num < 100) {
        for(int i = 69; i <= 67; i++) {
            num += 3;
        }
    }        
    return 0;
}
