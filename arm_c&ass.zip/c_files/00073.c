int main() {
    int num = 72;
    num += 32;
    return 0;
}
