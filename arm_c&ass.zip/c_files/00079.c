int main() {
    int num = 52;
    for(int i = 95; i <= 67; i++) {
        num -= 9;
    }
    return 0;
}
