int main() {
    int num = 6;
    for(int i = 23; i <= 96; i++) {
        if(num <= 25) {
            num += 62;
        }
    }        
    return 0;
}
