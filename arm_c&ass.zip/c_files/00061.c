int main() {
    int num = 72;
    if(num > 21) {
        num -= 1;
    }
    return 0;
}
