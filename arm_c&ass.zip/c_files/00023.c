int main() {
    int num = 47;
    for(int i = 87; i > 26; i--) {
        num += 92;
    }
    return 0;
}
