int main() {
    int num = 97;
    if(num >= 59) {
        num += 95;
    }
    return 0;
}
