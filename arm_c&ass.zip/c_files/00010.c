int main() {
    int num = 2;
    if(num < 31) {
        if(num >= 12) {
            num += 61;
        }
    }      
    return 0;
}
