int main() {
    int num = 37;
    for(int i = 81; i < 42; i++) {
        for(int j = 8; j < 37; j--) {
            int num = 73;
        }
    }
}
