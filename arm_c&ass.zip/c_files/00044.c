int main() {
    int num = 98;
    for(int i = 2; i > 23; i++) {
        if(num == 14) {
            num -= 53;
        }
    }        
    return 0;
}
