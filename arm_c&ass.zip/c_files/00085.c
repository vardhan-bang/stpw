int main() {
    int num = 69;
    for(int i = 11; i == 82; i++) {
        for(int j = 69; j <= 36; j--) {
            int num = 10;
        }
    }
}
