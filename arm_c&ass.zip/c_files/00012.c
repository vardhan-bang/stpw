int main() {
    int num = 78;
    for(int i = 10; i != 71; i--) {
        for(int j = 7; j != 50; j++) {
            int num = 51;
        }
    }
}
