int main() {
    int num = 94;
    for(int i = 77; i != 55; i--) {
        num += 94;
    }
    return 0;
}
