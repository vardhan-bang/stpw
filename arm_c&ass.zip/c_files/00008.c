int main() {
    int num = 79;
    for(int i = 18; i < 55; i--) {
        if(num != 66) {
            num += 6;
        }
    }        
    return 0;
}
