int main() {
    int num = 29;
    if(num != 99) {
        for(int i = 97; i != 61; i++) {
            num += 62;
        }
    }        
    return 0;
}
