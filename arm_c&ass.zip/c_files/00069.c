int main() {
    int num = 96;
    for(int i = 78; i > 59; i--) {
        if(num < 80) {
            num += 56;
        }
    }        
    return 0;
}
