int main() {
    int num = 5;
    if(num != 98) {
        for(int i = 63; i > 28; i--) {
            num += 85;
        }
    }        
    return 0;
}
