int main() {
    int num = 61;
    if(num != 88) {
        num -= 72;
    }
    return 0;
}
