int main() {
    int num = 63;
    if(num == 43) {
        num += 54;
    }
    return 0;
}
