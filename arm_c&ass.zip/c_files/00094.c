int main() {
    int num = 71;
    for(int i = 42; i != 42; i--) {
        if(num != 61) {
            num += 59;
        }
    }        
    return 0;
}
