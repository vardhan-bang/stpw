int main() {
    int num = 77;
    num += 36;
    return 0;
}
