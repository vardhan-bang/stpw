int main() {
    int num = 80;
    if(num > 53) {
        num -= 1;
    }
    return 0;
}
