int main() {
    int num = 61;
    num += 49;
    return 0;
}
