int main() {
    int num = 2;
    for(int i = 81; i > 22; i--) {
        num -= 65;
    }
    return 0;
}
