int main() {
    int num = 37;
    for(int i = 97; i != 45; i++) {
        if(num >= 91) {
            num += 27;
        }
    }        
    return 0;
}
