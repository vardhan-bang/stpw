int main() {
    int num = 46;
    for(int i = 95; i >= 82; i++) {
        if(num >= 51) {
            num -= 42;
        }
    }        
    return 0;
}
