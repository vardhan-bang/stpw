int main() {
    int num = 37;
    num -= 58;
    return 0;
}
