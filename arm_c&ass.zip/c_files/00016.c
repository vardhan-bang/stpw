int main() {
    int num = 71;
    if(num >= 94) {
        if(num >= 79) {
            num += 7;
        }
    }      
    return 0;
}
