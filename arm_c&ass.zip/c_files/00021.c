int main() {
    int num = 11;
    for(int i = 53; i <= 71; i++) {
        for(int j = 34; j == 91; j++) {
            int num = 85;
        }
    }
}
