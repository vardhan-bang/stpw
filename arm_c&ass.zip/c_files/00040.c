int main() {
    int num = 55;
    if(num < 63) {
        num -= 95;
    }
    return 0;
}
