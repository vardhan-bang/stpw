int main() {
    int num = 64;
    for(int i = 61; i < 66; i++) {
        num -= 7;
    }
    return 0;
}
