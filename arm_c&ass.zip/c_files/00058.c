int main() {
    int num = 71;
    if(num > 68) {
        if(num != 89) {
            num -= 32;
        }
    }      
    return 0;
}
