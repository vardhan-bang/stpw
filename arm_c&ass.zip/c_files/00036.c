int main() {
    int num = 49;
    if(num != 25) {
        for(int i = 10; i != 24; i++) {
            num -= 74;
        }
    }        
    return 0;
}
