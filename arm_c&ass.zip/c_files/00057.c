int main() {
    int num = 11;
    num -= 70;
    return 0;
}
