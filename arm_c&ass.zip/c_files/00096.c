int main() {
    int num = 38;
    for(int i = 51; i != 50; i--) {
        num += 28;
    }
    return 0;
}
