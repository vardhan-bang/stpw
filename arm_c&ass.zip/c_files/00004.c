int main() {
    int num = 10;
    for(int i = 31; i < 26; i--) {
        if(num == 19) {
            num += 99;
        }
    }        
    return 0;
}
