int main() {
    int num = 99;
    if(num == 2) {
        for(int i = 85; i >= 18; i--) {
            num += 33;
        }
    }        
    return 0;
}
