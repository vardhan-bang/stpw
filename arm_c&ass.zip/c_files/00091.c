int main() {
    int num = 79;
    for(int i = 92; i > 47; i++) {
        num -= 97;
    }
    return 0;
}
