int main() {
    int num = 92;
    for(int i = 1; i < 95; i--) {
        if(num < 35) {
            num -= 74;
        }
    }        
    return 0;
}
