int main() {
    int num = 46;
    num += 20;
    return 0;
}
