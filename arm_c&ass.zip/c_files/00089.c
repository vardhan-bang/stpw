int main() {
    int num = 45;
    for(int i = 76; i <= 28; i--) {
        num += 1;
    }
    return 0;
}
