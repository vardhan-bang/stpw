int main() {
    int num = 90;
    for(int i = 15; i == 53; i++) {
        num += 31;
    }
    return 0;
}
