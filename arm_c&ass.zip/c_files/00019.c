int main() {
    int num = 58;
    if(num < 55) {
        num -= 30;
    }
    return 0;
}
