int main() {
    int num = 63;
    for(int i = 31; i == 5; i--) {
        for(int j = 92; j >= 50; j--) {
            int num = 1;
        }
    }
}
