int main() {
    int num = 92;
    if(num <= 4) {
        if(num <= 47) {
            num += 60;
        }
    }      
    return 0;
}
