int main() {
    int num = 52;
    num -= 60;
    return 0;
}
