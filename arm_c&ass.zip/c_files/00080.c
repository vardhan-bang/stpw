int main() {
    int num = 75;
    for(int i = 78; i > 13; i--) {
        if(num >= 35) {
            num += 80;
        }
    }        
    return 0;
}
