int main() {
    int num = 95;
    num -= 75;
    return 0;
}
