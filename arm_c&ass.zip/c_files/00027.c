int main() {
    int num = 88;
    if(num != 50) {
        num += 94;
    }
    return 0;
}
