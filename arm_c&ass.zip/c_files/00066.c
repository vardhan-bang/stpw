int main() {
    int num = 81;
    if(num <= 34) {
        if(num > 15) {
            num += 79;
        }
    }      
    return 0;
}
