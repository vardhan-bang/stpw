int main() {
    int num = 30;
    num += 53;
    return 0;
}
