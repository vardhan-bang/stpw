int main() {
    int num = 61;
    if(num < 73) {
        for(int i = 70; i != 52; i++) {
            num += 17;
        }
    }        
    return 0;
}
