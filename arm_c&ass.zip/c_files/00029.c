int main() {
    int num = 49;
    for(int i = 31; i < 89; i--) {
        num += 98;
    }
    return 0;
}
