int main() {
    int num = 40;
    for(int i = 94; i <= 31; i--) {
        if(num > 14) {
            num -= 26;
        }
    }        
    return 0;
}
