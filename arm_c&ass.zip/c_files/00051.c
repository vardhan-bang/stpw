int main() {
    int num = 62;
    for(int i = 14; i <= 5; i--) {
        for(int j = 21; j < 68; j++) {
            int num = 35;
        }
    }
}
