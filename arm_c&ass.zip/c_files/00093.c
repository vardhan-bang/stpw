int main() {
    int num = 38;
    if(num <= 93) {
        if(num > 92) {
            num += 31;
        }
    }      
    return 0;
}
