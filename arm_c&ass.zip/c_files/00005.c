int main() {
    int num = 25;
    for(int i = 89; i <= 13; i--) {
        for(int j = 11; j <= 43; j--) {
            int num = 8;
        }
    }
}
