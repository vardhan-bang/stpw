int main() {
    int num = 63;
    for(int i = 2; i >= 36; i--) {
        num += 77;
    }
    return 0;
}
