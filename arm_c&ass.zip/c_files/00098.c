int main() {
    int num = 51;
    if(num < 58) {
        num += 54;
    }
    return 0;
}
