int main() {
    int num = 38;
    for(int i = 99; i == 57; i++) {
        num += 84;
    }
    return 0;
}
