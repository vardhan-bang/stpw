int main() {
    int num = 75;
    for(int i = 98; i != 50; i++) {
        if(num <= 39) {
            num += 37;
        }
    }        
    return 0;
}
