int main() {
    int num = 89;
    for(int i = 73; i < 65; i--) {
        for(int j = 30; j >= 1; j--) {
            int num = 47;
        }
    }
}
