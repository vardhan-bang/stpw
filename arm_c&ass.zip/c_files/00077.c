int main() {
    int num = 66;
    num += 93;
    return 0;
}
