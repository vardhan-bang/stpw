int main() {
    int num = 15;
    num += 71;
    return 0;
}
