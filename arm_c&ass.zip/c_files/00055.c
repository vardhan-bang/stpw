int main() {
    int num = 29;
    for(int i = 10; i >= 62; i++) {
        for(int j = 88; j < 2; j--) {
            int num = 61;
        }
    }
}
