int main() {
    int num = 72;
    if(num >= 26) {
        if(num > 68) {
            num -= 75;
        }
    }      
    return 0;
}
