int main() {
    int num = 30;
    num += 65;
    return 0;
}
