int main() {
    int num = 55;
    for(int i = 30; i < 71; i--) {
        if(num <= 69) {
            num -= 96;
        }
    }        
    return 0;
}
