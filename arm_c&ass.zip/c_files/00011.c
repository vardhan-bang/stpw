int main() {
    int num = 44;
    for(int i = 66; i != 56; i++) {
        num -= 38;
    }
    return 0;
}
