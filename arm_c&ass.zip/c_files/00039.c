int main() {
    int num = 61;
    if(num >= 66) {
        if(num >= 90) {
            num += 11;
        }
    }      
    return 0;
}
