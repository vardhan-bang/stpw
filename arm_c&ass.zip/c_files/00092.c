int main() {
    int num = 88;
    for(int i = 14; i == 47; i++) {
        if(num == 64) {
            num -= 35;
        }
    }        
    return 0;
}
