int main() {
    int num = 86;
    if(num >= 88) {
        for(int i = 44; i <= 23; i++) {
            num += 93;
        }
    }        
    return 0;
}
