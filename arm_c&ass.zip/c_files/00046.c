int main() {
    int num = 86;
    num -= 78;
    return 0;
}
