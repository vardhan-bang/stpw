int main() {
    int num = 40;
    if(num < 77) {
        num += 48;
    }
    return 0;
}
