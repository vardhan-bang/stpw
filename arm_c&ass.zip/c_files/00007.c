int main() {
    int num = 35;
    if(num < 69) {
        for(int i = 100; i <= 94; i--) {
            num += 98;
        }
    }        
    return 0;
}
