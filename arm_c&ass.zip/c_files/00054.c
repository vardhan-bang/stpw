int main() {
    int num = 63;
    for(int i = 38; i > 10; i++) {
        for(int j = 13; j != 39; j--) {
            int num = 25;
        }
    }
}
