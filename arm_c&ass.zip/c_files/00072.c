int main() {
    int num = 95;
    if(num > 29) {
        for(int i = 8; i == 72; i++) {
            num += 32;
        }
    }        
    return 0;
}
