int main() {
    int num = 81;
    if(num != 12) {
        num += 76;
    }
    return 0;
}
