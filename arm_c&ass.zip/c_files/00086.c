int main() {
    int num = 45;
    for(int i = 6; i != 42; i--) {
        if(num < 53) {
            num += 39;
        }
    }        
    return 0;
}
