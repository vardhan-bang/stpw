int main() {
    int num = 36;
    for(int i = 98; i <= 84; i--) {
        for(int j = 53; j == 12; j++) {
            int num = 23;
        }
    }
}
