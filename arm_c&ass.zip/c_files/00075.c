int main() {
    int num = 15;
    if(num <= 81) {
        num -= 40;
    }
    return 0;
}
