int main() {
    int num = 90;
    if(num >= 72) {
        for(int i = 64; i <= 63; i++) {
            num -= 49;
        }
    }        
    return 0;
}
