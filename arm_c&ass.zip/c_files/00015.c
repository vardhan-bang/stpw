int main() {
    int num = 27;
    if(num > 83) {
        for(int i = 62; i > 41; i++) {
            num += 28;
        }
    }        
    return 0;
}
