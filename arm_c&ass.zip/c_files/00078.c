int main() {
    int num = 39;
    for(int i = 100; i > 3; i++) {
        num += 33;
    }
    return 0;
}
