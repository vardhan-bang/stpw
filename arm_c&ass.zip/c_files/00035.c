int main() {
    int num = 31;
    for(int i = 78; i < 47; i--) {
        for(int j = 67; j == 28; j--) {
            int num = 92;
        }
    }
}
