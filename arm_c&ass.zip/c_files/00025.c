int main() {
    int num = 30;
    for(int i = 45; i >= 30; i--) {
        if(num >= 17) {
            num += 23;
        }
    }        
    return 0;
}
